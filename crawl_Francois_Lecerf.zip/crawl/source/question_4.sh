#!/usr/bin/env bash
wget http://www.freepatentsonline.com/8591332.html -P ../data -r -np --wait=1
